"""Sync img/<category>/<project>/ image folders into the website portfolio data.

Each non-empty project folder becomes one project with an ordered images array.
Images directly inside a category folder remain one-image project entries.
"""

from __future__ import annotations

import json
import re
import sys
import unicodedata
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
IMAGE_ROOT = ROOT / "img"
DATA_FILE = ROOT / "data" / "mockData.js"
START_MARKER = "// AUTO-IMPORTED PROJECTS START"
END_MARKER = "// AUTO-IMPORTED PROJECTS END"
IMAGE_EXTENSIONS = {".avif", ".bmp", ".gif", ".jpeg", ".jpg", ".png", ".tif", ".tiff", ".webp"}
CATEGORIES = {
    "banners": ("banners", "Banners"),
    "hoardings": ("hoardings", "Hoardings"),
    "interiors": ("interiors", "Interiors"),
    "branding": ("branding", "Branding"),
    "vehicle-branding": ("vehicle-branding", "Vehicle Branding"),
}


def slugify(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    return re.sub(r"[^a-z0-9]+", "-", normalized.lower()).strip("-") or "project"


def humanize(value: str) -> str:
    cleaned = re.sub(r"[_-]+", " ", value).strip()
    brand_names = {
        "boc": "BOC",
        "canon": "Canon",
        "cssl": "CSSL",
        "hnb": "HNB",
        "ibeach": "iBeach",
        "jss": "JSS",
        "msi": "MSI",
    }
    return " ".join(brand_names.get(word.casefold(), word.title()) for word in cleaned.split())


def natural_key(value: str) -> list[object]:
    return [int(part) if part.isdigit() else part.casefold() for part in re.split(r"(\d+)", value)]


def category_for(folder_name: str) -> tuple[str, str] | None:
    normalized = slugify(folder_name)
    aliases = {
        "vehicle": "vehicle-branding",
        "vehicle-branding": "vehicle-branding",
        "vehicle-brandings": "vehicle-branding",
        "banner": "banners",
        "banners": "banners",
        "hoarding": "hoardings",
        "hoardings": "hoardings",
        "interior": "interiors",
        "interiors": "interiors",
        "branding": "branding",
        "brandings": "branding",
    }
    key = aliases.get(normalized)
    return CATEGORIES.get(key) if key else None


def images_for(folder: Path) -> list[Path]:
    return sorted(
        (path for path in folder.rglob("*") if path.is_file() and path.suffix.casefold() in IMAGE_EXTENSIONS),
        key=lambda path: natural_key(path.relative_to(folder).as_posix()),
    )


def make_project(category_slug: str, category_label: str, project_name: str, images: list[Path]) -> dict[str, object]:
    relative_images = ["./" + path.relative_to(ROOT).as_posix() for path in images]
    title = humanize(project_name)
    return {
        "client": title,
        "title": title,
        "service": category_label,
        "category": category_slug,
        "categoryLabel": category_label,
        "label": category_label,
        "date": "",
        "year": "",
        "image": relative_images[0],
        "images": relative_images,
        "alt": f"{title} {category_label} project",
        "imageAlts": [f"{title} {category_label} photo {index}" for index in range(1, len(images) + 1)],
        "sourceKind": "img-folder-sync",
        "sourceFolder": images[0].parent.relative_to(IMAGE_ROOT).as_posix(),
    }


def scan_projects() -> list[dict[str, object]]:
    if not IMAGE_ROOT.is_dir():
        raise FileNotFoundError(f"Image directory not found: {IMAGE_ROOT}")

    projects: list[dict[str, object]] = []
    category_directories = sorted((path for path in IMAGE_ROOT.iterdir() if path.is_dir()), key=lambda path: path.name.casefold())
    for category_directory in category_directories:
        category = category_for(category_directory.name)
        if category is None:
            print(f"Skipping unsupported category folder: {category_directory.name}", file=sys.stderr)
            continue
        category_slug, category_label = category

        # Each named directory directly inside a category is one project/gallery.
        project_directories = sorted((path for path in category_directory.iterdir() if path.is_dir()), key=lambda path: path.name.casefold())
        for project_directory in project_directories:
            project_images = images_for(project_directory)
            if project_images:
                projects.append(make_project(category_slug, category_label, project_directory.name, project_images))

        # Loose category images each become their own one-photo portfolio item.
        for image in sorted((path for path in category_directory.iterdir() if path.is_file() and path.suffix.casefold() in IMAGE_EXTENSIONS), key=lambda path: natural_key(path.name)):
            projects.append(make_project(category_slug, category_label, image.stem, [image]))

    return projects


def update_data(projects: list[dict[str, object]]) -> None:
    source = DATA_FILE.read_text(encoding="utf-8")
    marker_start = source.find(START_MARKER)
    marker_end = source.find(END_MARKER)
    if marker_start < 0 or marker_end < marker_start:
        raise ValueError(f"Managed project markers missing from {DATA_FILE}")

    managed_start = marker_start + len(START_MARKER)
    existing = source[managed_start:marker_end].strip()
    if not existing.startswith("..."):
        raise ValueError("Managed projects must be stored as a spread JSON array")
    try:
        previous_projects = json.loads(existing[3:].strip())
    except json.JSONDecodeError as error:
        raise ValueError(f"Managed project data is invalid: {error}") from error

    # Keep projects maintained by the ZIP importer; replace only this folder sync's records.
    retained = [project for project in previous_projects if project.get("sourceKind") != "img-folder-sync"]
    combined = [*retained, *projects]
    replacement = "\n    ..." + json.dumps(combined, ensure_ascii=False, indent=6) + "\n    "
    updated = source[:managed_start] + replacement + source[marker_end:]
    temporary_file = DATA_FILE.with_suffix(".js.tmp")
    temporary_file.write_text(updated, encoding="utf-8", newline="\n")
    temporary_file.replace(DATA_FILE)


def main() -> int:
    try:
        projects = scan_projects()
        update_data(projects)
    except (OSError, ValueError) as error:
        print(f"Portfolio sync failed: {error}", file=sys.stderr)
        return 1

    photo_count = sum(len(project["images"]) for project in projects)
    print(f"Synced {len(projects)} projects and {photo_count} photos from {IMAGE_ROOT}")
    for project in projects:
        print(f"{project['categoryLabel']}: {project['title']} ({len(project['images'])} photo(s))")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
