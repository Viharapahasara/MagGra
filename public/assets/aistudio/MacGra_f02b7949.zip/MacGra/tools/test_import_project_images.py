"""Focused tests for ZIP image categorization and mock data updates."""

from __future__ import annotations

import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent))

from import_project_images import import_images, load_managed_projects, prune_missing_projects, write_managed_projects


MOCK_DATA = '''window.MACGRA_DATA = {
  projects: [
    { "client": "Existing", "category": "banners", "image": "./assets/images/manual.jpg" },
    // AUTO-IMPORTED PROJECTS START
    ...[]
    // AUTO-IMPORTED PROJECTS END
  ]
};
'''


class ImportProjectImagesTests(unittest.TestCase):
    def setUp(self) -> None:
        workspace_root = Path(__file__).resolve().parents[1]
        self.temporary_directory = tempfile.TemporaryDirectory(dir=workspace_root)
        self.root = Path(self.temporary_directory.name)
        (self.root / "data").mkdir()
        (self.root / "data/mockData.js").write_text(MOCK_DATA, encoding="utf-8")
        (self.root / "assets/images").mkdir(parents=True)

    def tearDown(self) -> None:
        self.temporary_directory.cleanup()

    def make_archive(self, name: str, members: dict[str, bytes]) -> Path:
        archive_path = self.root / name
        with zipfile.ZipFile(archive_path, "w") as archive:
            for member, content in members.items():
                archive.writestr(member, content)
        return archive_path

    def test_infers_known_categories_and_groups_shared_filename_themes(self) -> None:
        archive_path = self.make_archive("campaigns.zip", {
            "hoardings/central-bank-roadside/01-front.jpg": b"hoarding image",
            "interiors/office-partition-colombo/02-detail.jpg": b"partition detail",
            "interiors/office-partition-colombo/01-wide.jpg": b"partition wide",
            "misc/orchid-showcase/02-closeup.jpg": b"theme two",
            "misc/orchid-showcase/01-wide.jpg": b"theme one",
            "img/Banners/standee-one.jpg": b"standee",
            "img/Vehicle Branding/bank-van-wrap/front.jpg": b"vehicle wrap front",
            "img/Vehicle Branding/bank-van-wrap/detail.jpg": b"vehicle wrap detail",
            "img/Banners/flat-display.jpg": b"flat banner display",
        })

        self.assertEqual(import_images(archive_path, self.root, 1024 * 1024), 9)
        _, projects = load_managed_projects(self.root / "data/mockData.js")
        self.assertEqual(len(projects), 6)
        by_title = {project["title"]: project for project in projects}
        hoarding = by_title["Central Bank Roadside"]
        interior = by_title["Office Partition Colombo"]
        branding = by_title["Orchid Showcase"]
        vehicle = by_title["Bank Van Wrap"]
        self.assertEqual(hoarding["category"], "hoardings")
        self.assertEqual(interior["category"], "interiors")
        self.assertEqual(branding["category"], "branding")
        self.assertEqual(vehicle["category"], "vehicle-branding")
        self.assertEqual(len(interior["images"]), 2)
        self.assertTrue(interior["images"][0].endswith("01-wide.jpg"))
        self.assertEqual(interior["image"], interior["images"][0])
        self.assertTrue(all((self.root / path.removeprefix("./")).is_file() for path in interior["images"]))
        self.assertEqual(len(vehicle["images"]), 2)
        self.assertEqual(len(by_title["Standee One"]["images"]), 1)
        self.assertEqual(len(by_title["Flat Display"]["images"]), 1)
        self.assertEqual({project["category"] for project in projects}, {
            "banners", "hoardings", "interiors", "branding", "vehicle-branding"
        })

    def test_reimport_replaces_same_archive_and_keeps_other_archive(self) -> None:
        first_archive = self.make_archive("first.zip", {"banner_one.jpg": b"first"})
        second_archive = self.make_archive("second.zip", {"glass_panel.jpg": b"glass"})

        import_images(first_archive, self.root, 1024 * 1024)
        import_images(second_archive, self.root, 1024 * 1024)
        import_images(first_archive, self.root, 1024 * 1024)

        _, projects = load_managed_projects(self.root / "data/mockData.js")
        self.assertEqual(len(projects), 2)
        self.assertEqual({project["sourceArchive"] for project in projects}, {"first.zip", "second.zip"})

    def test_whatsapp_timestamp_names_fall_back_to_uncategorized(self) -> None:
        archive_path = self.make_archive("whatsapp-export.zip", {
            "WhatsApp Image 2026-11-03 at 12.39.50.jpeg": b"image one",
            "WhatsApp Image 2026-11-03 at 12.39.48.jpeg": b"image two",
        })

        self.assertEqual(import_images(archive_path, self.root, 1024 * 1024), 2)
        _, projects = load_managed_projects(self.root / "data/mockData.js")
        self.assertEqual({project["category"] for project in projects}, {"branding"})

    def test_ignores_unsafe_paths_and_non_image_members(self) -> None:
        archive_path = self.make_archive("safe.zip", {
            "../outside/hoarding.jpg": b"unsafe",
            "docs/readme.txt": b"not an image",
            "safe/signage.png": b"safe",
        })

        self.assertEqual(import_images(archive_path, self.root, 1024 * 1024), 1)
        self.assertFalse((self.root.parent / "outside/hoarding.jpg").exists())

    def test_rejects_archive_over_configured_image_size(self) -> None:
        archive_path = self.make_archive("large.zip", {"banner.jpg": b"12345"})
        with self.assertRaisesRegex(ValueError, "size limit"):
            import_images(archive_path, self.root, 4)

    def test_prunes_deleted_gallery_images_and_empty_managed_projects(self) -> None:
        existing_image = self.root / "assets/images/interiors/office/front.jpg"
        existing_image.parent.mkdir(parents=True)
        existing_image.write_bytes(b"existing")
        data_path = self.root / "data/mockData.js"
        source, _ = load_managed_projects(data_path)
        projects = [
            {
                "title": "Office Partition",
                "image": "./assets/images/interiors/office/front.jpg",
                "images": [
                    "./assets/images/interiors/office/front.jpg",
                    "./assets/images/interiors/office/deleted.jpg",
                ],
                "imageAlts": ["Front view", "Deleted view"],
            },
            {"title": "Removed Project", "image": "./assets/images/banners/deleted.jpg"},
        ]
        write_managed_projects(data_path, source, projects)

        self.assertEqual(prune_missing_projects(self.root), (1, 2))
        _, retained = load_managed_projects(data_path)
        self.assertEqual(len(retained), 1)
        self.assertEqual(retained[0]["images"], ["./assets/images/interiors/office/front.jpg"])
        self.assertEqual(retained[0]["imageAlts"], ["Front view"])


if __name__ == "__main__":
    unittest.main()
