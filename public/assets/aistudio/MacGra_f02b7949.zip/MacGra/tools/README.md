# Import project images

## Sync Existing `img/` Folders

When photos are already arranged in `img/<category>/<client-or-project>/`, regenerate the portfolio entries with:

```powershell
C:/Users/Vihara/AppData/Local/Programs/Python/Python313/python.exe tools/sync_img_portfolio.py
```

The sync maps Banners, Branding, Hoardings, Interiors and Vehicle Branding to the canonical portfolio filters. Each non-empty client folder becomes one project with an `images` array; the first image is the card thumbnail and the modal shows the full responsive gallery. Images placed directly inside a category folder are added as individual projects. Empty folders are skipped. The script replaces only its own folder-sync records in `data/mockData.js` and leaves other managed ZIP imports in place.

The site is static, so image sorting runs locally before you preview or deploy the website. The importer uses only Python's standard library and does not upload images.

```powershell
C:/Users/Vihara/AppData/Local/Programs/Python/Python313/python.exe tools/import_project_images.py "C:/path/to/project-images.zip"
```

It reads supported image files from the ZIP and sorts them into the fixed folders `assets/images/banners/`, `assets/images/hoardings/`, `assets/images/interiors/`, `assets/images/branding/`, and `assets/images/vehicle-branding/`. Folder names or filename keywords identify categories: standees/displays map to banners; billboards/outdoor hoardings map to hoardings; partitions/glass/interior decor map to interiors; signs/corporate identity map to branding; van wraps/stickers map to vehicle branding. Unrecognized images default to branding so no extra top-level categories are created.

Category/project/photo paths are preserved as category and project directories. For example, a ZIP containing `interiors/office-partition-colombo/front.jpg` and `interiors/office-partition-colombo/detail.jpg` creates one project with both images, stored under `assets/images/interiors/office-partition-colombo/`. All photos in a named project subfolder are grouped. Images directly in a category folder remain separate project entries.

Each imported project has an `images` array containing all its image paths. The `image` field is also written as the first image for thumbnail/backwards compatibility. The portfolio card uses that first photo; opening it shows a gallery with next/previous buttons, keyboard arrow navigation, a photo counter, and touch swipe support. Filter tabs are generated from the categories present in `mockData.js`.

If the ZIP has a known category folder, put project folders directly inside it, then place all photos for that work in the project folder. Example: `interiors/office-partition-colombo/photo-01.jpg`. Descriptive folder names become the project title. A wrapper such as `img/` is ignored when determining the category.

The portfolio page builds its filter tabs from the categories in `mockData.js`; no HTML edit is needed for a new category. Re-importing a ZIP with the same filename replaces that archive's managed entries and leaves hand-authored projects and other ZIP imports alone. The default uncompressed image limit is 500 MB; adjust it with `--max-size-mb`.

Classification is based on filenames and archive paths only. Visual recognition is not enabled. Use descriptive image filenames for the best automatic grouping.

Run the importer tests with:

```powershell
C:/Users/Vihara/AppData/Local/Programs/Python/Python313/python.exe -m unittest tools/test_import_project_images.py
```

If imported files have been manually removed, clean only stale entries in the managed project block with:

```powershell
C:/Users/Vihara/AppData/Local/Programs/Python/Python313/python.exe tools/import_project_images.py --prune-missing
```

Hand-authored project entries are not pruned. For a project with several photos, the portfolio modal provides next/previous buttons, a photo counter, keyboard arrows and touch swipe navigation.
