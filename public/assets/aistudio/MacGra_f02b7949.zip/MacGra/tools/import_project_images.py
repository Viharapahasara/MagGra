"""Import images from a ZIP into categorized asset folders and mockData.js.

Categories are inferred from filenames and archive paths. If no known keyword is
present, shared filename terms group related unknown images into a new category.
This tool does not perform visual recognition; image content is not uploaded or
sent to a remote service.

Usage:
    python tools/import_project_images.py path/to/project-images.zip
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import sys
import unicodedata
import zipfile
from collections import Counter
from dataclasses import dataclass
from datetime import date
from pathlib import Path, PurePosixPath
from stat import S_ISLNK

PROJECT_ROOT = Path(__file__).resolve().parents[1]
ASSETS_ROOT = Path("assets/images")
DATA_FILE = Path("data/mockData.js")
START_MARKER = "// AUTO-IMPORTED PROJECTS START"
END_MARKER = "// AUTO-IMPORTED PROJECTS END"
IMAGE_EXTENSIONS = {".avif", ".bmp", ".gif", ".jpeg", ".jpg", ".png", ".tif", ".tiff", ".webp"}
IGNORED_WORDS = {
    "a", "an", "and", "art", "asset", "assets", "at", "client", "clients", "final",
    "image", "img", "macgra", "misc", "new", "photo", "project", "projects", "render", "scan",
    "the", "upload", "uploads", "v", "version", "wa", "whatsapp",
}
CATEGORY_RULES = (
    (("vehicle", "vehicles", "van", "vans", "wrap", "wraps", "sticker", "stickers", "mobile"), (), "vehicle-branding", "Vehicle Branding"),
    (("banner", "banners", "standee", "standees", "display", "displays"), (), "banners", "Banners"),
    (("hoarding", "hoardings", "billboard", "billboards", "outdoor"), (), "hoardings", "Hoardings"),
    (("partition", "partitions", "glass", "interior", "interiors", "reception", "office", "workspace", "decor"), (), "interiors", "Interiors"),
    (("branding", "brand", "corporate", "identity", "signboard", "signboards", "signage", "logo", "logos"), (), "branding", "Branding"),
)
DEFAULT_CATEGORY = ("branding", "Branding")
MASTER_CATEGORIES = ("banners", "hoardings", "interiors", "branding", "vehicle-branding")
GENERIC_DIRECTORIES = {"assets", "client", "clients", "img", "image", "images", "misc", "photo", "photos", "projects", "portfolio", "upload", "uploads", "final"}


@dataclass
class ArchiveImage:
    member_name: str
    filename: str
    contents: bytes
    category: str = ""
    category_label: str = ""
    project_key: str = ""
    project_name: str = ""


def slugify(value: str) -> str:
    normalized = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
    slug = re.sub(r"[^a-z0-9]+", "-", normalized.lower()).strip("-")
    return slug or "uncategorized-projects"


def filename_tokens(value: str) -> set[str]:
    parts = PurePosixPath(value).parts
    text_parts = [*parts[:-1], Path(parts[-1]).stem] if parts else []
    normalized = unicodedata.normalize("NFKD", " ".join(text_parts)).encode("ascii", "ignore").decode("ascii")
    return {
        token.lower()
        for token in re.findall(r"[A-Za-z]{2,}", normalized)
        if token.lower() not in IGNORED_WORDS
    }


def infer_known_category(value: str) -> tuple[str, str] | None:
    tokens = filename_tokens(value)
    for required, supporting, slug, label in CATEGORY_RULES:
        if tokens.intersection(required) and (not supporting or tokens.intersection(supporting)):
            return slug, label
    return None


def project_group(image: ArchiveImage) -> tuple[str, str]:
    """Group all photos under a named directory; leave flat category photos independent."""
    parts = PurePosixPath(image.member_name).parts
    directories = list(parts[:-1])
    category_directory_index = next(
        (index for index, folder in enumerate(directories) if infer_known_category(folder)),
        None,
    )

    if category_directory_index is not None:
        candidate_directories = directories[category_directory_index + 1:]
    else:
        candidate_directories = [folder for folder in directories if slugify(folder) not in GENERIC_DIRECTORIES]

    meaningful = [folder for folder in candidate_directories if slugify(folder) not in GENERIC_DIRECTORIES]
    if meaningful:
        project_path = meaningful[0]
        project_name = Path(project_path).name.replace("_", " ").replace("-", " ").strip().title()
        return slugify(project_path), project_name

    stem = Path(image.filename).stem
    project_name = stem.replace("_", " ").replace("-", " ").strip().title() or "Project Image"
    return f"image-{hashlib.sha1(image.member_name.encode('utf-8')).hexdigest()[:10]}", project_name


def natural_sort_key(value: str) -> list[object]:
    return [int(part) if part.isdigit() else part.lower() for part in re.split(r"(\d+)", value)]


def infer_unknown_themes(images: list[ArchiveImage]) -> dict[str, tuple[str, str]]:
    return {image.member_name: DEFAULT_CATEGORY for image in images if not image.category}


def read_archive(archive_path: Path, max_size_bytes: int) -> list[ArchiveImage]:
    try:
        archive = zipfile.ZipFile(archive_path)
    except (OSError, zipfile.BadZipFile) as error:
        raise ValueError(f"Cannot read ZIP archive: {error}") from error

    images: list[ArchiveImage] = []
    total_size = 0
    with archive:
        for member in archive.infolist():
            path = PurePosixPath(member.filename)
            if member.is_dir() or path.suffix.lower() not in IMAGE_EXTENSIONS:
                continue
            unix_mode = member.external_attr >> 16
            if S_ISLNK(unix_mode):
                continue
            if path.is_absolute() or ".." in path.parts:
                print(f"Skipping unsafe archive path: {member.filename}", file=sys.stderr)
                continue
            total_size += member.file_size
            if total_size > max_size_bytes:
                raise ValueError(f"Archive images exceed the {max_size_bytes // (1024 * 1024)} MB size limit")
            contents = archive.read(member)
            filename = sanitize_filename(path.name)
            images.append(ArchiveImage(member.filename, filename, contents))

    if not images:
        raise ValueError("The ZIP archive contains no supported image files")
    return images


def sanitize_filename(filename: str) -> str:
    suffix = Path(filename).suffix.lower()
    stem = Path(filename).stem
    normalized = unicodedata.normalize("NFKD", stem).encode("ascii", "ignore").decode("ascii")
    safe_stem = re.sub(r"[^A-Za-z0-9_-]+", "-", normalized).strip("-_") or "project-image"
    return f"{safe_stem[:100]}{suffix}"


def load_managed_projects(data_path: Path) -> tuple[str, list[dict[str, str]]]:
    source = data_path.read_text(encoding="utf-8")
    start = source.find(START_MARKER)
    end = source.find(END_MARKER)
    if start < 0 or end < 0 or end < start:
        raise ValueError(f"Could not find managed project markers in {data_path}")

    content_start = start + len(START_MARKER)
    managed_source = source[content_start:end].strip()
    if not managed_source.startswith("..."):
        raise ValueError("Managed project block must be a JavaScript spread expression")
    try:
        managed_projects = json.loads(managed_source[3:].strip())
    except json.JSONDecodeError as error:
        raise ValueError(f"Managed project block is not valid JSON: {error}") from error
    if not isinstance(managed_projects, list):
        raise ValueError("Managed project block must contain a JSON array")
    return source, managed_projects


def write_managed_projects(data_path: Path, source: str, projects: list[dict[str, str]]) -> None:
    start = source.find(START_MARKER)
    end = source.find(END_MARKER)
    content_start = start + len(START_MARKER)
    replacement = "\n    ..." + json.dumps(projects, ensure_ascii=False, indent=6) + "\n    "
    updated = source[:content_start] + replacement + source[end:]
    temporary_path = data_path.with_suffix(data_path.suffix + ".tmp")
    temporary_path.write_text(updated, encoding="utf-8", newline="\n")
    temporary_path.replace(data_path)


def unique_destination(category: str, project_key: str, filename: str, content: bytes, root: Path, reserved: set[str]) -> Path:
    category_dir = slugify(category)
    project_dir = slugify(project_key)
    relative = Path(ASSETS_ROOT, category_dir, project_dir, filename)
    destination = root / relative
    if relative.as_posix() not in reserved and not destination.exists():
        return destination

    digest = hashlib.sha256(content).hexdigest()[:10]
    stem, suffix = Path(filename).stem, Path(filename).suffix
    candidate = Path(ASSETS_ROOT, category_dir, project_dir, f"{stem}-{digest}{suffix}")
    counter = 2
    while candidate.as_posix() in reserved or (root / candidate).exists():
        candidate = Path(ASSETS_ROOT, category_dir, project_dir, f"{stem}-{digest}-{counter}{suffix}")
        counter += 1
    return root / candidate


def import_images(archive_path: Path, root: Path, max_size_bytes: int) -> int:
    archive_path = archive_path.resolve()
    if not archive_path.is_file():
        raise ValueError(f"ZIP file does not exist: {archive_path}")

    images = read_archive(archive_path, max_size_bytes)
    for category in MASTER_CATEGORIES:
        (root / ASSETS_ROOT / category).mkdir(parents=True, exist_ok=True)
    archive_name = archive_path.name
    for image in images:
        path_parts = PurePosixPath(image.member_name).parts
        directory_category = next(
            (infer_known_category(folder) for folder in path_parts[:-1] if infer_known_category(folder)),
            None,
        )
        category = directory_category or infer_known_category(image.member_name)
        if category:
            image.category, image.category_label = category

    themes = infer_unknown_themes(images)
    for image in images:
        if not image.category:
            image.category, image.category_label = themes[image.member_name]
        image.project_key, image.project_name = project_group(image)

    data_path = root / DATA_FILE
    source, managed_projects = load_managed_projects(data_path)
    previous_archive_projects = [
        project for project in managed_projects if project.get("sourceArchive") == archive_name
    ]
    retained_projects = [
        project for project in managed_projects if project.get("sourceArchive") != archive_name
    ]
    reserved_paths = {
        project["image"].removeprefix("./")
        for project in managed_projects
        if project.get("image")
    }
    manual_source = source[:source.find(START_MARKER)]
    manual_images = re.findall(r"\bimage\s*:\s*[\"']([^\"']+)[\"']", manual_source)
    reserved_paths.update(path.removeprefix("./") for path in manual_images)
    previous_paths = {
        path.removeprefix("./")
        for project in previous_archive_projects
        for path in project.get("images", [project.get("image", "")])
        if path
    }
    reserved_paths.difference_update(previous_paths)

    month = date.today().strftime("%Y-%m")
    manual_categories = re.findall(r"\bcategory\s*:\s*[\"']([^\"']+)[\"']", manual_source)
    category_counts = Counter(manual_categories)
    category_counts.update(project.get("category", "") for project in retained_projects)
    imported_projects: list[dict[str, object]] = []
    written_paths: list[Path] = []

    grouped_images: dict[tuple[str, str], list[ArchiveImage]] = {}
    for image in images:
        grouped_images.setdefault((image.category, image.project_key), []).append(image)

    for (category, project_key), project_images in grouped_images.items():
        project_images.sort(key=lambda image: natural_sort_key(image.member_name))
        image_paths: list[str] = []
        for image in project_images:
            destination = unique_destination(category, project_key, image.filename, image.contents, root, reserved_paths)
            relative_path = destination.relative_to(root).as_posix()
            reserved_paths.add(relative_path)
            destination.parent.mkdir(parents=True, exist_ok=True)
            destination.write_bytes(image.contents)
            written_paths.append(destination)
            image_paths.append(f"./{relative_path}")

        category_label = project_images[0].category_label
        project_name = project_images[0].project_name
        category_counts[category] += 1
        image_number = category_counts[category]
        imported_projects.append({
            "client": "MacGra Projects",
            "title": project_name,
            "service": category_label,
            "category": slugify(category),
            "categoryLabel": category_label,
            "label": category_label,
            "date": month,
            "year": month[:4],
            "image": image_paths[0],
            "images": image_paths,
            "alt": f"{project_name} {category_label} project",
            "imageAlts": [f"{project_name} {category_label} photo {index}" for index in range(1, len(image_paths) + 1)],
            "sourceArchive": archive_name,
            "sourceMember": project_images[0].member_name,
            "sourceMembers": [image.member_name for image in project_images],
            "sourceProject": project_key,
        })

    updated_projects = [*retained_projects, *imported_projects]
    try:
        write_managed_projects(data_path, source, updated_projects)
    except OSError:
        for destination in written_paths:
            destination.unlink(missing_ok=True)
        raise

    referenced = {
        path.removeprefix("./")
        for project in updated_projects
        for path in project.get("images", [project.get("image", "")])
        if path
    }
    referenced.update(path.removeprefix("./") for path in manual_images)
    for project in previous_archive_projects:
        old_images = project.get("images", [project.get("image", "")])
        for image_path in old_images:
            relative_image = image_path.removeprefix("./")
            old_path = (root / relative_image).resolve()
            assets_root = (root / ASSETS_ROOT).resolve()
            if old_path.is_relative_to(assets_root) and relative_image not in referenced:
                old_path.unlink(missing_ok=True)
                for parent in (old_path.parent, old_path.parent.parent):
                    try:
                        parent.rmdir()
                    except OSError:
                        break

    return len(images)


def prune_missing_projects(root: Path) -> tuple[int, int]:
    """Remove missing photos from the managed block and drop managed projects with no photos."""
    data_path = root / DATA_FILE
    source, managed_projects = load_managed_projects(data_path)
    retained: list[dict[str, object]] = []
    removed_projects = 0
    removed_images = 0

    for project in managed_projects:
        project_images = project.get("images") or [project.get("image", "")]
        image_alts = project.get("imageAlts", [])
        existing_images: list[str] = []
        existing_alts: list[str] = []
        for index, image_path in enumerate(project_images):
            if not image_path:
                removed_images += 1
                continue
            relative_path = image_path.removeprefix("./")
            resolved_path = (root / relative_path).resolve()
            assets_root = (root / ASSETS_ROOT).resolve()
            if not resolved_path.is_relative_to(assets_root) or not resolved_path.is_file():
                removed_images += 1
                continue
            existing_images.append(image_path)
            if index < len(image_alts):
                existing_alts.append(image_alts[index])

        if not existing_images:
            removed_projects += 1
            continue

        project["images"] = existing_images
        project["image"] = existing_images[0]
        if image_alts:
            project["imageAlts"] = existing_alts
        retained.append(project)

    if removed_projects or removed_images:
        write_managed_projects(data_path, source, retained)
    return removed_projects, removed_images


def main() -> int:
    parser = argparse.ArgumentParser(description="Categorize ZIP images and update MacGra portfolio data.")
    parser.add_argument("zip_file", type=Path, nargs="?", help="ZIP archive containing project images")
    parser.add_argument("--root", type=Path, default=PROJECT_ROOT, help="Website root (defaults to this repository)")
    parser.add_argument("--max-size-mb", type=int, default=500, help="Maximum total uncompressed image size; default: 500 MB")
    parser.add_argument("--prune-missing", action="store_true", help="Remove managed project photos that no longer exist on disk")
    args = parser.parse_args()

    if args.max_size_mb <= 0:
        parser.error("--max-size-mb must be a positive integer")
    if not args.zip_file and not args.prune_missing:
        parser.error("provide a ZIP file, --prune-missing, or both")

    try:
        if args.prune_missing:
            removed_projects, removed_images = prune_missing_projects(args.root.resolve())
            print(f"Removed {removed_images} missing image reference(s) from {removed_projects} managed project(s).")
        if args.zip_file:
            count = import_images(args.zip_file, args.root.resolve(), args.max_size_mb * 1024 * 1024)
    except (OSError, ValueError, zipfile.BadZipFile) as error:
        print(f"Import failed: {error}", file=sys.stderr)
        return 1

    if args.zip_file:
        print(f"Imported {count} image(s) into {args.root.resolve() / ASSETS_ROOT}")
        print(f"Updated {args.root.resolve() / DATA_FILE}; portfolio filters are generated from project categories.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
