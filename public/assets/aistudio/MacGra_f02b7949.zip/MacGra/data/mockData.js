/* === CENTRALIZED SITE CONTENT ===
   Add projects here and keep their date in YYYY-MM format so the home preview stays current.
   Replace image URLs with local files in assets/images/ or your own hosted campaign URLs.
*/
window.MACGRA_DATA = {
  brand: {
    name: "MacGra",
    descriptor: "Advertising"
  },
  hero: {
    eyebrow: "Sri Lankan craft. Made to be seen.",
    headlineStart: "Your creative",
    headlineEnd: "partner for",
    headlineAccent: "Sri Lankan spaces.",
    description: "Elevate your brand with premium advertising and inspiring interior solutions."
  },
  about: {
    kicker: "Made here, for here / 01",
    headline: "Good work",
    emphasis: "belongs",
    closing: "somewhere.",
    paragraphs: [
      "MacGra Advertising helps Sri Lankan businesses show up with confidence, on the street and inside the spaces where people work. From a first sketch to the final installation, our local team brings design, fabrication and fit-out together.",
      "Thoughtful details. Dependable delivery. A little island character in every good idea."
    ]
  },
  stats: [
    { value: "01", suffix: "team", label: "Design through installation" },
    { value: "03", suffix: "crafts", label: "Banners, hoardings, interiors" },
    { value: "LK", suffix: "based", label: "Built for Sri Lankan spaces" }
  ],
  services: [
    {
      title: "Advertising",
      icon: "advertising",
      eyebrow: "Be seen, out there",
      description: "Clear, confident brand visibility, designed for the places your customers pass every day.",
      items: ["Banners & event graphics", "Hoardings & billboards", "Shopfront signs & displays"]
    },
    {
      title: "Interior solutions",
      icon: "interiors",
      eyebrow: "Feel at home at work",
      description: "Considered details that make a workplace feel welcoming, useful and unmistakably yours.",
      items: ["Office partitions", "Reception desks", "Wall graphics & art"]
    }
  ],
  categories: [
    { slug: "banners", label: "Banners" },
    { slug: "hoardings", label: "Hoardings" },
    { slug: "interiors", label: "Interiors" },
    { slug: "branding", label: "Branding" },
    { slug: "vehicle-branding", label: "Vehicle Branding" }
  ],
  projects: [
    // AUTO-IMPORTED PROJECTS START
    ...[
      {
            "client": "Canon",
            "title": "Canon",
            "service": "Banners",
            "category": "banners",
            "categoryLabel": "Banners",
            "label": "Banners",
            "date": "",
            "year": "",
            "image": "./img/Banners/canon/WhatsApp Image 2026-11-03 at 12.26.49.jpeg",
            "images": [
                  "./img/Banners/canon/WhatsApp Image 2026-11-03 at 12.26.49.jpeg",
                  "./img/Banners/canon/WhatsApp Image 2026-11-03 at 12.26.51.jpeg"
            ],
            "alt": "Canon Banners project",
            "imageAlts": [
                  "Canon Banners photo 1",
                  "Canon Banners photo 2"
            ],
            "sourceKind": "img-folder-sync",
            "sourceFolder": "Banners/canon"
      },
      {
            "client": "CSSL",
            "title": "CSSL",
            "service": "Banners",
            "category": "banners",
            "categoryLabel": "Banners",
            "label": "Banners",
            "date": "",
            "year": "",
            "image": "./img/Banners/CSSL/WhatsApp Image 2026-11-03 at 12.39.35 (2).jpeg",
            "images": [
                  "./img/Banners/CSSL/WhatsApp Image 2026-11-03 at 12.39.35 (2).jpeg"
            ],
            "alt": "CSSL Banners project",
            "imageAlts": [
                  "CSSL Banners photo 1"
            ],
            "sourceKind": "img-folder-sync",
            "sourceFolder": "Banners/CSSL"
      },
      {
            "client": "MSI",
            "title": "MSI",
            "service": "Banners",
            "category": "banners",
            "categoryLabel": "Banners",
            "label": "Banners",
            "date": "",
            "year": "",
            "image": "./img/Banners/msi/WhatsApp Image 2026-11-03 at 12.26.48 (1).jpeg",
            "images": [
                  "./img/Banners/msi/WhatsApp Image 2026-11-03 at 12.26.48 (1).jpeg"
            ],
            "alt": "MSI Banners project",
            "imageAlts": [
                  "MSI Banners photo 1"
            ],
            "sourceKind": "img-folder-sync",
            "sourceFolder": "Banners/msi"
      },
      {
            "client": "New Monis",
            "title": "New Monis",
            "service": "Banners",
            "category": "banners",
            "categoryLabel": "Banners",
            "label": "Banners",
            "date": "",
            "year": "",
            "image": "./img/Banners/New Monis/WhatsApp Image 2026-11-03 at 12.26.57 (2).jpeg",
            "images": [
                  "./img/Banners/New Monis/WhatsApp Image 2026-11-03 at 12.26.57 (2).jpeg"
            ],
            "alt": "New Monis Banners project",
            "imageAlts": [
                  "New Monis Banners photo 1"
            ],
            "sourceKind": "img-folder-sync",
            "sourceFolder": "Banners/New Monis"
      },
      {
            "client": "Biyagama Pradeshiya Sabha",
            "title": "Biyagama Pradeshiya Sabha",
            "service": "Branding",
            "category": "branding",
            "categoryLabel": "Branding",
            "label": "Branding",
            "date": "",
            "year": "",
            "image": "./img/Branding/Biyagama pradeshiya sabha/WhatsApp Image 2026-11-03 at 12.33.59.jpeg",
            "images": [
                  "./img/Branding/Biyagama pradeshiya sabha/WhatsApp Image 2026-11-03 at 12.33.59.jpeg"
            ],
            "alt": "Biyagama Pradeshiya Sabha Branding project",
            "imageAlts": [
                  "Biyagama Pradeshiya Sabha Branding photo 1"
            ],
            "sourceKind": "img-folder-sync",
            "sourceFolder": "Branding/Biyagama pradeshiya sabha"
      },
      {
            "client": "BOC",
            "title": "BOC",
            "service": "Branding",
            "category": "branding",
            "categoryLabel": "Branding",
            "label": "Branding",
            "date": "",
            "year": "",
            "image": "./img/Branding/BOC/WhatsApp Image 2026-11-03 at 12.36.34.jpeg",
            "images": [
                  "./img/Branding/BOC/WhatsApp Image 2026-11-03 at 12.36.34.jpeg"
            ],
            "alt": "BOC Branding project",
            "imageAlts": [
                  "BOC Branding photo 1"
            ],
            "sourceKind": "img-folder-sync",
            "sourceFolder": "Branding/BOC"
      },
      {
            "client": "Elephant House",
            "title": "Elephant House",
            "service": "Branding",
            "category": "branding",
            "categoryLabel": "Branding",
            "label": "Branding",
            "date": "",
            "year": "",
            "image": "./img/Branding/Elephant House/WhatsApp Image 2026-11-03 at 12.33.56 (1).jpeg",
            "images": [
                  "./img/Branding/Elephant House/WhatsApp Image 2026-11-03 at 12.33.56 (1).jpeg",
                  "./img/Branding/Elephant House/WhatsApp Image 2026-11-03 at 12.33.57.jpeg"
            ],
            "alt": "Elephant House Branding project",
            "imageAlts": [
                  "Elephant House Branding photo 1",
                  "Elephant House Branding photo 2"
            ],
            "sourceKind": "img-folder-sync",
            "sourceFolder": "Branding/Elephant House"
      },
      {
            "client": "iBeach",
            "title": "iBeach",
            "service": "Branding",
            "category": "branding",
            "categoryLabel": "Branding",
            "label": "Branding",
            "date": "",
            "year": "",
            "image": "./img/Branding/iBeach/WhatsApp Image 2026-11-03 at 12.39.31.jpeg",
            "images": [
                  "./img/Branding/iBeach/WhatsApp Image 2026-11-03 at 12.39.31.jpeg"
            ],
            "alt": "iBeach Branding project",
            "imageAlts": [
                  "iBeach Branding photo 1"
            ],
            "sourceKind": "img-folder-sync",
            "sourceFolder": "Branding/iBeach"
      },
      {
            "client": "Port City Duty Free",
            "title": "Port City Duty Free",
            "service": "Branding",
            "category": "branding",
            "categoryLabel": "Branding",
            "label": "Branding",
            "date": "",
            "year": "",
            "image": "./img/Branding/Port City Duty Free/WhatsApp Image 2026-11-03 at 12.35.57.jpeg",
            "images": [
                  "./img/Branding/Port City Duty Free/WhatsApp Image 2026-11-03 at 12.35.57.jpeg",
                  "./img/Branding/Port City Duty Free/WhatsApp Image 2026-11-03 at 12.35.58.jpeg"
            ],
            "alt": "Port City Duty Free Branding project",
            "imageAlts": [
                  "Port City Duty Free Branding photo 1",
                  "Port City Duty Free Branding photo 2"
            ],
            "sourceKind": "img-folder-sync",
            "sourceFolder": "Branding/Port City Duty Free"
      },
      {
            "client": "Energ1",
            "title": "Energ1",
            "service": "Hoardings",
            "category": "hoardings",
            "categoryLabel": "Hoardings",
            "label": "Hoardings",
            "date": "",
            "year": "",
            "image": "./img/Hoardings/Energ1/WhatsApp Image 2026-11-03 at 12.25.55.jpeg",
            "images": [
                  "./img/Hoardings/Energ1/WhatsApp Image 2026-11-03 at 12.25.55.jpeg",
                  "./img/Hoardings/Energ1/WhatsApp Image 2026-11-03 at 12.27.54.jpeg",
                  "./img/Hoardings/Energ1/WhatsApp Image 2026-11-03 at 12.30.04.jpeg"
            ],
            "alt": "Energ1 Hoardings project",
            "imageAlts": [
                  "Energ1 Hoardings photo 1",
                  "Energ1 Hoardings photo 2",
                  "Energ1 Hoardings photo 3"
            ],
            "sourceKind": "img-folder-sync",
            "sourceFolder": "Hoardings/Energ1"
      },
      {
            "client": "HNB Finance",
            "title": "HNB Finance",
            "service": "Hoardings",
            "category": "hoardings",
            "categoryLabel": "Hoardings",
            "label": "Hoardings",
            "date": "",
            "year": "",
            "image": "./img/Hoardings/HNB Finance/WhatsApp Image 2026-11-03 at 12.25.56.jpeg",
            "images": [
                  "./img/Hoardings/HNB Finance/WhatsApp Image 2026-11-03 at 12.25.56.jpeg",
                  "./img/Hoardings/HNB Finance/WhatsApp Image 2026-11-03 at 12.25.57.jpeg"
            ],
            "alt": "HNB Finance Hoardings project",
            "imageAlts": [
                  "HNB Finance Hoardings photo 1",
                  "HNB Finance Hoardings photo 2"
            ],
            "sourceKind": "img-folder-sync",
            "sourceFolder": "Hoardings/HNB Finance"
      },
      {
            "client": "Prageeth Auto Traders",
            "title": "Prageeth Auto Traders",
            "service": "Hoardings",
            "category": "hoardings",
            "categoryLabel": "Hoardings",
            "label": "Hoardings",
            "date": "",
            "year": "",
            "image": "./img/Hoardings/Prageeth Auto Traders/WhatsApp Image 2026-11-03 at 12.25.49.jpeg",
            "images": [
                  "./img/Hoardings/Prageeth Auto Traders/WhatsApp Image 2026-11-03 at 12.25.49.jpeg"
            ],
            "alt": "Prageeth Auto Traders Hoardings project",
            "imageAlts": [
                  "Prageeth Auto Traders Hoardings photo 1"
            ],
            "sourceKind": "img-folder-sync",
            "sourceFolder": "Hoardings/Prageeth Auto Traders"
      },
      {
            "client": "Energ1",
            "title": "Energ1",
            "service": "Interiors",
            "category": "interiors",
            "categoryLabel": "Interiors",
            "label": "Interiors",
            "date": "",
            "year": "",
            "image": "./img/Interiors/Energ1/WhatsApp Image 2026-11-03 at 12.27.49.jpeg",
            "images": [
                  "./img/Interiors/Energ1/WhatsApp Image 2026-11-03 at 12.27.49.jpeg",
                  "./img/Interiors/Energ1/WhatsApp Image 2026-11-03 at 12.27.53.jpeg"
            ],
            "alt": "Energ1 Interiors project",
            "imageAlts": [
                  "Energ1 Interiors photo 1",
                  "Energ1 Interiors photo 2"
            ],
            "sourceKind": "img-folder-sync",
            "sourceFolder": "Interiors/Energ1"
      },
      {
            "client": "Interior",
            "title": "Interior",
            "service": "Interiors",
            "category": "interiors",
            "categoryLabel": "Interiors",
            "label": "Interiors",
            "date": "",
            "year": "",
            "image": "./img/Interiors/Interior/WhatsApp Image 2026-11-03 at 12.32.43 (1).jpeg",
            "images": [
                  "./img/Interiors/Interior/WhatsApp Image 2026-11-03 at 12.32.43 (1).jpeg",
                  "./img/Interiors/Interior/WhatsApp Image 2026-11-03 at 12.33.35.jpeg",
                  "./img/Interiors/Interior/WhatsApp Image 2026-11-03 at 12.33.54.jpeg",
                  "./img/Interiors/Interior/WhatsApp Image 2026-11-03 at 12.33.55.jpeg"
            ],
            "alt": "Interior Interiors project",
            "imageAlts": [
                  "Interior Interiors photo 1",
                  "Interior Interiors photo 2",
                  "Interior Interiors photo 3",
                  "Interior Interiors photo 4"
            ],
            "sourceKind": "img-folder-sync",
            "sourceFolder": "Interiors/Interior"
      },
      {
            "client": "JSS Consultants",
            "title": "JSS Consultants",
            "service": "Interiors",
            "category": "interiors",
            "categoryLabel": "Interiors",
            "label": "Interiors",
            "date": "",
            "year": "",
            "image": "./img/Interiors/JSS Consultants/WhatsApp Image 2026-11-03 at 12.39.36 (1).jpeg",
            "images": [
                  "./img/Interiors/JSS Consultants/WhatsApp Image 2026-11-03 at 12.39.36 (1).jpeg",
                  "./img/Interiors/JSS Consultants/WhatsApp Image 2026-11-03 at 12.39.37 (1).jpeg",
                  "./img/Interiors/JSS Consultants/WhatsApp Image 2026-11-03 at 12.39.37.jpeg"
            ],
            "alt": "JSS Consultants Interiors project",
            "imageAlts": [
                  "JSS Consultants Interiors photo 1",
                  "JSS Consultants Interiors photo 2",
                  "JSS Consultants Interiors photo 3"
            ],
            "sourceKind": "img-folder-sync",
            "sourceFolder": "Interiors/JSS Consultants"
      },
      {
            "client": "National Gem & Jewellery Authority",
            "title": "National Gem & Jewellery Authority",
            "service": "Interiors",
            "category": "interiors",
            "categoryLabel": "Interiors",
            "label": "Interiors",
            "date": "",
            "year": "",
            "image": "./img/Interiors/National Gem & Jewellery Authority/WhatsApp Image 2026-11-03 at 12.39.38 (1).jpeg",
            "images": [
                  "./img/Interiors/National Gem & Jewellery Authority/WhatsApp Image 2026-11-03 at 12.39.38 (1).jpeg",
                  "./img/Interiors/National Gem & Jewellery Authority/WhatsApp Image 2026-11-03 at 12.39.39 (2).jpeg",
                  "./img/Interiors/National Gem & Jewellery Authority/WhatsApp Image 2026-11-03 at 12.39.40.jpeg",
                  "./img/Interiors/National Gem & Jewellery Authority/WhatsApp Image 2026-11-03 at 12.39.45 (1).jpeg",
                  "./img/Interiors/National Gem & Jewellery Authority/WhatsApp Image 2026-11-03 at 12.39.45.jpeg",
                  "./assets/images/interiors/national-gem-jewellery-authority/WhatsApp Image 2026-11-03 at 12.39.48.jpeg"
            ],
            "alt": "National Gem & Jewellery Authority Interiors project",
            "imageAlts": [
                  "National Gem & Jewellery Authority Interiors photo 1",
                  "National Gem & Jewellery Authority Interiors photo 2",
                  "National Gem & Jewellery Authority Interiors photo 3",
                  "National Gem & Jewellery Authority Interiors photo 4",
                  "National Gem & Jewellery Authority Interiors photo 5",
                  "National Gem & Jewellery Authority Interiors photo 6"
            ],
            "sourceKind": "img-folder-sync",
            "sourceFolder": "Interiors/National Gem & Jewellery Authority"
      },
      {
            "client": "Star",
            "title": "Star",
            "service": "Interiors",
            "category": "interiors",
            "categoryLabel": "Interiors",
            "label": "Interiors",
            "date": "",
            "year": "",
            "image": "./img/Interiors/Star/WhatsApp Image 2026-11-03 at 12.30.16 (1).jpeg",
            "images": [
                  "./img/Interiors/Star/WhatsApp Image 2026-11-03 at 12.30.16 (1).jpeg",
                  "./img/Interiors/Star/WhatsApp Image 2026-11-03 at 12.30.17 (1).jpeg"
            ],
            "alt": "Star Interiors project",
            "imageAlts": [
                  "Star Interiors photo 1",
                  "Star Interiors photo 2"
            ],
            "sourceKind": "img-folder-sync",
            "sourceFolder": "Interiors/Star"
      },
      {
            "client": "HNB Finance",
            "title": "HNB Finance",
            "service": "Vehicle Branding",
            "category": "vehicle-branding",
            "categoryLabel": "Vehicle Branding",
            "label": "Vehicle Branding",
            "date": "",
            "year": "",
            "image": "./img/vehicle-branding/HNB Finance/WhatsApp Image 2026-11-03 at 12.24.52 (1).jpeg",
            "images": [
                  "./img/vehicle-branding/HNB Finance/WhatsApp Image 2026-11-03 at 12.24.52 (1).jpeg",
                  "./img/vehicle-branding/HNB Finance/WhatsApp Image 2026-11-03 at 12.24.52.jpeg"
            ],
            "alt": "HNB Finance Vehicle Branding project",
            "imageAlts": [
                  "HNB Finance Vehicle Branding photo 1",
                  "HNB Finance Vehicle Branding photo 2"
            ],
            "sourceKind": "img-folder-sync",
            "sourceFolder": "vehicle-branding/HNB Finance"
      }
]
    // AUTO-IMPORTED PROJECTS END
  ],
  /* Replace these contact placeholders and social URLs with approved business details. */
  contact: {
    email: "hello@yourdomain.lk",
    phone: "+94 XX XXX XXXX",
    phoneLink: "+94XXXXXXXXX",
    location: "Your street address, Nugegoda, Sri Lanka",
    note: "Serving businesses across the island.",
    socials: [
      { name: "Instagram", url: "https://www.instagram.com/", icon: "instagram" },
      { name: "LinkedIn", url: "https://www.linkedin.com/", icon: "linkedin" },
      { name: "Facebook", url: "https://www.facebook.com/", icon: "facebook" }
    ]
  }
};
