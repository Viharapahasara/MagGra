/* Shared helpers used by the page components. */
window.MacGra = window.MacGra || {};

window.MacGra.escapeHTML = (value) => String(value).replace(/[&<>"']/g, (character) => ({
  "&": "&amp;",
  "<": "&lt;",
  ">": "&gt;",
  '"': "&quot;",
  "'": "&#39;"
})[character]);