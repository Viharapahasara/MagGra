/* Initialize page features after their data and component scripts load. */
(() => {
  const data = window.MACGRA_DATA;
  const app = window.MacGra;

  if (!data) throw new Error("MacGra content data is missing. Check data/mockData.js.");
  if (!app) throw new Error("MacGra components did not load. Check the script order in the page.");

  app.renderContent(data);
  app.initNavigation();
  app.initPortfolioFilters(data);
  app.initProjectModal(data);
  app.initAtmosphere();
  app.initContactForm();
})();