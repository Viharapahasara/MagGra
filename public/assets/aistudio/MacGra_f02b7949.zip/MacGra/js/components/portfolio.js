/* Filter portfolio cards and manage the project photo gallery dialog. */
window.MacGra = window.MacGra || {};

(() => {
  function initPortfolioFilters(data) {
    const filters = document.querySelector(".filters");
    if (!filters) return;

    const escapeHTML = window.MacGra.escapeHTML;
    const categoryLabels = new Map((data.categories || []).map((category) => [category.slug, category.label]));
    data.projects.forEach((project) => {
      if (!categoryLabels.has(project.category)) {
        categoryLabels.set(project.category, project.categoryLabel || project.label || project.category);
      }
    });

    const categories = [...categoryLabels.entries()].sort((first, second) => first[1].localeCompare(second[1]));
    filters.innerHTML = [
      '<button class="filter-button" type="button" data-filter="all" aria-pressed="true">All work</button>',
      ...categories.map(([category, label]) => `
        <button class="filter-button" type="button" data-filter="${escapeHTML(category)}" aria-pressed="false">${escapeHTML(label)}</button>
      `)
    ].join("");

    filters.addEventListener("click", (event) => {
      const button = event.target.closest(".filter-button");
      if (!button) return;

      filters.querySelectorAll(".filter-button").forEach((filterButton) => {
        filterButton.setAttribute("aria-pressed", String(filterButton === button));
      });
      document.querySelectorAll("#project-grid .project").forEach((project) => {
        project.hidden = button.dataset.filter !== "all" && project.dataset.category !== button.dataset.filter;
      });
    });
  }

  function initProjectModal(data) {
    const grid = document.querySelector("#project-grid");
    const modal = document.querySelector("#project-modal");
    if (!grid || !modal) return;

    const closeButton = modal.querySelector(".modal-close");
    const imageElement = modal.querySelector(".gallery-image");
    const counter = modal.querySelector(".gallery-counter");
    const previousButton = modal.querySelector(".gallery-previous");
    const nextButton = modal.querySelector(".gallery-next");
    let lastTrigger;
    let activeImages = [];
    let activeImageIndex = 0;
    let touchStartX = 0;

    const renderActiveImage = () => {
      const project = modal.activeProject;
      imageElement.src = activeImages[activeImageIndex];
      imageElement.alt = project.imageAlts?.[activeImageIndex] || project.alt || project.title;
      counter.textContent = `${activeImageIndex + 1} / ${activeImages.length}`;
      const hasGallery = activeImages.length > 1;
      previousButton.hidden = !hasGallery;
      nextButton.hidden = !hasGallery;
      counter.hidden = !hasGallery;
    };

    const moveGallery = (step) => {
      if (activeImages.length < 2) return;
      activeImageIndex = (activeImageIndex + step + activeImages.length) % activeImages.length;
      renderActiveImage();
    };

    const closeModal = () => {
      modal.classList.remove("is-open");
      modal.setAttribute("aria-hidden", "true");
      document.body.classList.remove("modal-open");
      lastTrigger?.focus();
    };

    grid.addEventListener("click", (event) => {
      const trigger = event.target.closest("[data-project-index]");
      if (!trigger) return;

      const project = data.projects[Number(trigger.dataset.projectIndex)];
      if (!project) return;
      lastTrigger = trigger;
      activeImages = project.images?.length ? project.images : [project.image];
      activeImageIndex = 0;
      modal.activeProject = project;
      renderActiveImage();
      modal.querySelector(".modal-caption h2").textContent = project.client || project.title;
      modal.querySelector(".modal-caption span").textContent = project.year
        ? `${project.service} / ${project.year}`
        : project.service;
      modal.classList.add("is-open");
      modal.setAttribute("aria-hidden", "false");
      document.body.classList.add("modal-open");
      closeButton.focus();
    });

    closeButton.addEventListener("click", closeModal);
    previousButton.addEventListener("click", () => moveGallery(-1));
    nextButton.addEventListener("click", () => moveGallery(1));
    imageElement.addEventListener("touchstart", (event) => {
      touchStartX = event.changedTouches[0].clientX;
    }, { passive: true });
    imageElement.addEventListener("touchend", (event) => {
      const distance = event.changedTouches[0].clientX - touchStartX;
      if (Math.abs(distance) > 45) moveGallery(distance < 0 ? 1 : -1);
    }, { passive: true });
    modal.addEventListener("click", (event) => {
      if (event.target === modal) closeModal();
    });
    document.addEventListener("keydown", (event) => {
      if (!modal.classList.contains("is-open")) return;
      if (event.key === "Escape") closeModal();
      if (event.key === "ArrowLeft") moveGallery(-1);
      if (event.key === "ArrowRight") moveGallery(1);
    });
  }

  window.MacGra.initPortfolioFilters = initPortfolioFilters;
  window.MacGra.initProjectModal = initProjectModal;
})();