/* Render page copy, services, projects, and contact details from the site data. */
window.MacGra = window.MacGra || {};

(() => {
  const icons = {
    arrow: '<svg viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M3 13 13 3M4 3h9v9"/></svg>',
    advertising: '<svg viewBox="0 0 72 72" fill="none" stroke="currentColor" stroke-width="1.2" aria-hidden="true"><path d="M36 58V31m0 12c-2-12-15-18-22-9 7 11 15 13 22 9Zm0-6c2-13 15-19 22-10-7 12-15 14-22 10Zm0-10c-1-11-8-17-15-17 0 9 5 15 15 17Zm0 0c1-11 8-17 15-17 0 9-5 15-15 17ZM27 58h18M29 63h14"/><path d="M36 14v4m-19 4 4 2m30-2-4 2" stroke="var(--gold)"/></svg>',
    interiors: '<svg viewBox="0 0 72 72" fill="none" stroke="currentColor" stroke-width="1.2" aria-hidden="true"><path d="M17 56V19h38v37M17 32h38M36 19v37M22 25h8m12 0h8M22 39h8m12 0h8M22 47h8m12 0h8"/><path d="M36 19c-6-4-7-10-3-13 4 3 5 7 3 13Zm0 0c6-4 7-10 3-13-4 3-5 7-3 13Z" stroke="var(--gold)"/></svg>',
    instagram: '<svg viewBox="0 0 20 20" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><rect x="3" y="3" width="14" height="14" rx="4"/><circle cx="10" cy="10" r="3.2"/><circle cx="14.6" cy="5.6" r=".8" fill="currentColor" stroke="none"/></svg>',
    linkedin: '<svg viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M4.6 7.5H2V18h2.6V7.5ZM3.3 2a1.5 1.5 0 1 0 0 3 1.5 1.5 0 0 0 0-3ZM18 12c0-3.1-1.6-4.6-3.8-4.6-1.8 0-2.6 1-3.1 1.7V7.5H8.5V18h2.6v-5.2c0-1.4.3-2.8 2-2.8s1.8 1.6 1.8 2.9V18H18v-6Z"/></svg>',
    facebook: '<svg viewBox="0 0 20 20" fill="currentColor" aria-hidden="true"><path d="M11.5 18v-7h2.4l.4-2.8h-2.8V6.4c0-.8.2-1.3 1.4-1.3h1.5V2.6c-.3 0-1.2-.1-2.3-.1-2.3 0-3.9 1.4-3.9 4v1.7H5.8V11h2.4v7h3.3Z"/></svg>'
  };

  function renderContent(data) {
    const escapeHTML = window.MacGra.escapeHTML;
    const hero = document.querySelector("#hero-title");

    if (hero) {
      document.querySelector("#hero-eyebrow").textContent = data.hero.eyebrow;
      hero.innerHTML = `${escapeHTML(data.hero.headlineStart)}<br>${escapeHTML(data.hero.headlineEnd)} <em>${escapeHTML(data.hero.headlineAccent)}</em>`;
      document.querySelector("#hero-description").textContent = data.hero.description;
    }

    const aboutHeadline = document.querySelector("#about-headline");
    if (aboutHeadline) {
      document.querySelector("#about-kicker").textContent = data.about.kicker;
      aboutHeadline.innerHTML = `${escapeHTML(data.about.headline)}<br><em>${escapeHTML(data.about.emphasis)}</em><br>${escapeHTML(data.about.closing)}`;
      document.querySelector("#about-copy").innerHTML = `${data.about.paragraphs.map((paragraph) => `<p>${escapeHTML(paragraph)}</p>`).join("")}<a class="text-link" href="#contact">Let's make something matter ${icons.arrow}</a>`;
      document.querySelector("#stats-list").innerHTML = data.stats.map((stat) => `
        <div class="stat"><strong>${escapeHTML(stat.value)}<span>${escapeHTML(stat.suffix)}</span></strong><small>${escapeHTML(stat.label)}</small></div>
      `).join("");
    }

    const serviceList = document.querySelector("#service-list");
    if (serviceList) {
      serviceList.innerHTML = data.services.map((service, index) => `
        <article class="service-card reveal service-card--${escapeHTML(service.icon)}">
          <div class="service-card-top"><span class="service-number">0${index + 1} / SERVICE</span><span class="service-motif" aria-hidden="true">${icons[service.icon] || icons.advertising}</span></div>
          <p class="service-eyebrow">${escapeHTML(service.eyebrow)}</p><h3>${escapeHTML(service.title)}</h3><p class="service-description">${escapeHTML(service.description)}</p>
          <ul>${service.items.map((item) => `<li>${escapeHTML(item)}</li>`).join("")}</ul>
          <a class="text-link" href="#contact">Talk through a project ${icons.arrow}</a>
        </article>
      `).join("");
    }

    const projectGrid = document.querySelector("#project-grid");
    if (projectGrid) {
      const projects = [...data.projects].sort((first, second) => second.date.localeCompare(first.date));
      const displayProjects = document.body.dataset.page === "home" ? projects.slice(0, 2) : projects;

      projectGrid.innerHTML = displayProjects.map((project) => `
        <article class="project" data-category="${escapeHTML(project.category)}">
          <div class="project-visual">
            <img src="${escapeHTML(project.images?.[0] || project.image)}" alt="${escapeHTML(project.imageAlts?.[0] || project.alt)}" loading="lazy">
            <span class="project-badge">${escapeHTML(project.label)}</span>
            <button class="project-open" type="button" aria-label="View ${escapeHTML(project.title)}" data-project-index="${data.projects.indexOf(project)}"><span class="sr-only">View project</span>${icons.arrow}</button>
          </div>
          <div class="project-meta"><div><h3>${escapeHTML(project.client || project.title)}</h3><p>${escapeHTML(project.service)}</p></div>${project.year ? `<span>${escapeHTML(project.year)}</span>` : ""}</div>
        </article>
      `).join("");
    }

    const contactDetails = document.querySelector("#contact-details");
    if (contactDetails) {
      contactDetails.innerHTML = `
        <div class="contact-detail"><small>Email</small><a href="mailto:${escapeHTML(data.contact.email)}">${escapeHTML(data.contact.email)}</a></div>
        <div class="contact-detail"><small>Phone</small><a href="tel:${escapeHTML(data.contact.phoneLink)}">${escapeHTML(data.contact.phone)}</a></div>
        <div class="contact-detail"><small>Studio</small><span>${escapeHTML(data.contact.location)}<br>${escapeHTML(data.contact.note)}</span></div>
      `;
      document.querySelector("#social-links").innerHTML = data.contact.socials.map((social) => `
        <a href="${escapeHTML(social.url)}" aria-label="${escapeHTML(social.name)}" target="_blank" rel="noreferrer">${icons[social.icon] || icons.arrow}</a>
      `).join("");
    }

    document.querySelectorAll("#year").forEach((year) => {
      year.textContent = new Date().getFullYear();
    });
  }

  window.MacGra.renderContent = renderContent;
})();