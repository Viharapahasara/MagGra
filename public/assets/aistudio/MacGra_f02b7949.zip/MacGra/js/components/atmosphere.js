/* Reveal content as it enters view and support the pointer-following ambient light. */
window.MacGra = window.MacGra || {};

window.MacGra.initAtmosphere = () => {
  const revealElements = document.querySelectorAll(".reveal");
  const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

  if (!("IntersectionObserver" in window) || reducedMotion) {
    revealElements.forEach((element) => element.classList.add("is-visible"));
  } else {
    const observer = new IntersectionObserver((entries, activeObserver) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          entry.target.classList.add("is-visible");
          activeObserver.unobserve(entry.target);
        }
      });
    }, { threshold: 0.12 });
    revealElements.forEach((element) => observer.observe(element));
  }

  if (!window.matchMedia("(pointer: fine)").matches || reducedMotion) return;

  let scheduled = false;
  window.addEventListener("pointermove", (event) => {
    if (scheduled) return;
    scheduled = true;
    requestAnimationFrame(() => {
      document.documentElement.style.setProperty("--pointer-x", `${event.clientX}px`);
      document.documentElement.style.setProperty("--pointer-y", `${event.clientY}px`);
      document.body.classList.add("has-pointer");
      scheduled = false;
    });
  }, { passive: true });
};