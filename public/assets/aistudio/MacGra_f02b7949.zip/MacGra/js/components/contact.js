/* Validate the local demo contact form and show its confirmation message. */
window.MacGra = window.MacGra || {};

window.MacGra.initContactForm = () => {
  const form = document.querySelector("#contact-form");
  if (!form) return;

  form.addEventListener("submit", (event) => {
    event.preventDefault();
    if (!form.reportValidity()) return;
    form.querySelector(".form-status").textContent = "Thanks for reaching out. We will be in touch soon.";
    form.reset();
  });
};