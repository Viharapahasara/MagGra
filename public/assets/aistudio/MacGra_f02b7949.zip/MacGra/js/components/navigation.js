/* Toggle the mobile menu and keep its accessible state in sync. */
window.MacGra = window.MacGra || {};

window.MacGra.initNavigation = () => {
  const toggle = document.querySelector(".menu-toggle");
  const navigation = document.querySelector(".nav-links");
  if (!toggle || !navigation) return;

  const setOpen = (isOpen) => {
    toggle.setAttribute("aria-expanded", String(isOpen));
    toggle.setAttribute("aria-label", isOpen ? "Close navigation" : "Open navigation");
    navigation.classList.toggle("is-open", isOpen);
    document.body.classList.toggle("menu-open", isOpen);
  };

  toggle.addEventListener("click", () => setOpen(toggle.getAttribute("aria-expanded") !== "true"));
  navigation.addEventListener("click", (event) => {
    if (event.target.closest("a")) setOpen(false);
  });
  window.addEventListener("resize", () => {
    if (window.innerWidth > 850) setOpen(false);
  });
};