# MacGra Advertising Website

A lightweight, data-driven portfolio built with plain HTML, CSS, and JavaScript. Open `index.html` or `portfolio.html` directly, or serve this folder with any static file server.

## Project Layout

- `index.html`, `portfolio.html`: home and portfolio page entry points. They stay at the project root so local file previews and static hosting routes continue to work.
- `css/styles.css`: page layout, components, responsive rules, and motion.
- `css/theme/tokens.css`: shared brand colors, typography, and layout tokens.
- `js/app.js`: application startup and component initialization.
- `js/components/`: content rendering, navigation, portfolio gallery, atmosphere effects, and contact form behavior.
- `js/utils.js`: shared HTML escaping helper.
- `data/mockData.js`: shared brand, service, contact, and project data. Keep the auto-imported project markers intact; the image tools update that block.
- `assets/`: site assets, including imported project images under `assets/images/<category>/<project>/`.
- `img/`: organized source images used by the folder-sync workflow.
- `tools/`: image import/sync scripts and their tests.

## Project Image Checks

Run the image importer tests with the Python interpreter configured for this workspace:

```powershell
python -m unittest tools/test_import_project_images.py
```